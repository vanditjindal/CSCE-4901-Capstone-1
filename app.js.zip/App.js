
import * as React from 'react';
import MainContainer from './Navigation/MainContainer';

export default function App() {
  return (
    <MainContainer/>
  );
}
